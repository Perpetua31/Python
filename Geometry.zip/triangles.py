#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 24 01:15:29 2024

@author: Perpetua Senatus

Functions to calculate 
the  perimeter and area 
of a triangle (2-D) 

"""

# The perimeter function accepts a triangle's
# side a , side b and side c as arguments 
# and returns the triangle's perimeter.
def perimeter(side_a, side_b, side_c):
    return side_a + side_b + side_c


# The area function accepts a triangle's base and
# height as arguments and returns the triangle's 
# area.
def area(base, height):
    return (base * height)/2