#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 24 01:16:23 2024

@author: Perpetua Senatus

Functions to calculate
the volume and surface area 
of a sphere (3-D)

"""
import math 

pi=math.pi


# The volume function accepts a sphere's radius
# as argument and returns the sphere's volume.
def volume (radius):
    return (4/3) * math.pi * radius**3


# The surface_area function accepts a sphere's radius
# as argument and returns the sphere's surface area.
def  surface_area (radius):
    return 4 * math.pi * radius**2


    