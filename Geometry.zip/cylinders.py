#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 24 01:16:46 2024

@author: Perpetua Senatus

Functions to calculate 
the volume and surface area 
of a cylinder (3-D)

"""

import math

pi=math.pi

# The volume function accepts a cylinder's 
#radius and height as arguments and 
#returns the cylinder's volume.
def volume (radius , height):
    return math.pi * radius**2 * height 


# The surface_area function accepts a cylinder's 
#radius and height as arguments 
# and returns the cylinder's surface area.
def surface_area(radius, height):
    return (2 * math.pi * radius * height) + (2 * math.pi * radius**2)

